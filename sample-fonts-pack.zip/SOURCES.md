# EasyFonts — Sample pack

4 font reali dal repository ufficiale Google Fonts.

- Lato-Regular.ttf: https://github.com/google/fonts/tree/main/ofl/lato
- Lato-Bold.ttf: https://github.com/google/fonts/tree/main/ofl/lato
- Abel-Regular.ttf: https://github.com/google/fonts/tree/main/ofl/abel
- Bangers-Regular.ttf: https://github.com/google/fonts/tree/main/ofl/bangers

Ogni cartella contiene la licenza SIL Open Font License originale.
